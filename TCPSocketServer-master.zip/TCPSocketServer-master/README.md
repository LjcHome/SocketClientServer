TCPSocketServer
===============

TCP Socket Server - Swing Desktop Application which is communicate with Android Application

Connection port is : 5657. So in Android application you must have to define 5657 port while connecting this socket server.

You can download SocketAndroidClient (https://github.com/prashantadesara/SocketAndroidClient) 

Found main tutorial from here: 
http://prashantandroid.blogspot.in/2013/07/android-client-connected-with-socket.html
