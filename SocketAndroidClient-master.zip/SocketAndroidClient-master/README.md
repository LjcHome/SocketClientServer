SocketAndroidClient
===================

Android Socket Client Connected with Socket Server (i.e. Desktop Socket Server)

This application is used to connect with Socket server and doing chatting between server and android application.

You can download SocketServer (https://github.com/prashantadesara/TCPSocketServer)

Found main tutorial from here: 
http://prashantandroid.blogspot.in/2013/07/android-client-connected-with-socket.html
